﻿using System.Windows.Forms;

namespace TestAssembly{
    public class Program{
        public Program(){
            MessageBox.Show("Test Assembly !!");
        }
    }
}
